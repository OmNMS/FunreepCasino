﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class CardList : MonoBehaviour
{
    public List<Card> deck= new List<Card>();

    /// <summary>
    /// Returns a card of the given rank and suit
    /// </summary>
    /// <param name="rankValue">rank of required card</param>
    /// <param name="suitValue">suit of required card</param>
    /// <returns>card of the given rank and suit</returns>
    public Card GetCard(int rankValue, int suitValue)
    {
        foreach (Card card in deck)
        {
            if (card.rank == (Rank)rankValue && card.suit == (Suit)suitValue)
            {
                return card;
            }
        }
        return null;
    }
}
