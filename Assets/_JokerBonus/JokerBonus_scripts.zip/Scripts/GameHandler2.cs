using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameHandler2 : MonoBehaviour
{
    //ui objects
    public TMP_Text Score_Text, Bet_Text, Double_Up_Text;
    [SerializeField] HorizontalLayoutGroup centerCards, doubleUpPanel;

    //cards
    CardList deck;
    [SerializeField] Card defaultCard;
    Card mysteryCard;

    List<Card> dealedCards = new List<Card>();
    List<Card> heldCards = new List<Card>();
    List<Card> hand = new List<Card>();

    int betValue = 0;
    float score = 200;
    bool isHand = false;
    [SerializeField] int dealLimit = 2;
    int dealCount = 0;

    private void Awake()
    {
        StartCoroutine(APIHandler.GetBalance(UserDetails.playerId, (response) =>
        {
            //player's overall balance is assigned to the initial score of the game
            score = response.balance;
        }));
    }

    void Start()
    {
        deck = GetComponent<CardList>();

        for (int i = 0; i < 5; i++)
        {
            GameObject card = Instantiate(defaultCard.gameObject, centerCards.transform);
            card.transform.SetParent(centerCards.transform);
            dealedCards.Add(card.GetComponent<Card>());
        }

        Bet_Text.text = betValue.ToString();
        Score_Text.text = score.ToString();
    }

    /// <summary>
    /// Place bet value
    /// </summary>
    public void Bet()
    {
        if (score > 0 && dealCount == 0)
        {
            betValue++;
            Bet_Text.text = betValue.ToString();

            SetScore(-1);
        }
    }

    /// <summary>
    /// Sets bet value to ui
    /// </summary>
    /// <param name="value">betValue</param>
    public void SetBetValue(int value)
    {
        betValue = value;
        Bet_Text.text = betValue.ToString();
    }

    /// <summary>
    /// Sets score/win amount when won
    /// </summary>
    /// <param name="value">win amount</param>
    public void SetScore(float value)
    {
        score += value;
        Score_Text.text = score.ToString();
    }

    public void Deal()
    {
        if (dealCount < dealLimit && !isHand && betValue > 0)
        {
            //clearing previously dealed cards that are not held
            foreach (Card card in dealedCards)
            {
                if (card != null)
                {
                    if (!heldCards.Contains(card))
                    {
                        Destroy(card.gameObject);
                    }
                }
            }
            dealedCards.Clear();

            StartCoroutine(APIHandler.BetsPlaced(UserDetails.playerId, betValue, (response) =>
            {
                if (response.status == 200)
                {
                    for(int i = 0; i < response.data.card_list.Count; i++)
                    {
                        int[] card = response.data.card_list[i];
                        dealedCards.Add(deck.GetCard(card[0], card[1]));
                    }
                }
            }));

            for (int i = 0; i < dealedCards.Count - heldCards.Count; i++)
            {
                GameObject dealedCard = Instantiate(dealedCards[i].gameObject, centerCards.transform);
                dealedCard.transform.SetParent(centerCards.transform);
                dealedCards.Add(dealedCard.GetComponent<Card>());
            }


            CheckCard();
            dealCount++;
        }
    }

    /// <summary>
    /// Check for cards that potentially makes a hand
    /// </summary>
    public void CheckCard()
    {
        //for Jacks or Better
        foreach (Card card in dealedCards)
        {
            if (card.rank >= Rank.Jack)
            {
                HoldCard(card);
            }
        }

        //for same ranks
        for (int i = 0; i < dealedCards.Count; i++)
        {
            for (int j = i + 1; j < dealedCards.Count; j++)
            {
                if (dealedCards[i].rank == dealedCards[j].rank)
                {
                    HoldCard(dealedCards[i]);
                    HoldCard(dealedCards[j]);
                }
            }
        }

        CheckForHand();
    }

    /// <summary>
    /// Check if we have a poker hand
    /// </summary>
    public void CheckForHand()
    {
        hand.Clear();
        hand.AddRange(dealedCards);

        foreach (Card card in heldCards)
        {
            if (!dealedCards.Contains(card))
            {
                hand.Add(card);
            }
        }
        Debug.Log("Total cards = " + hand.Count);

        //sorting by rank
        hand.Sort(new CardRankComparer());

        isHand = IsFlush(hand) || IsPair(hand) || IsStraight(hand);
    }

    private bool IsStraight(List<Card> hand)
    {
        //check if cards are in sequence
        int count = 0;
        for (int i = 0; i < hand.Count - 1; i++)
        {
            if (hand[i].rank - 1 == hand[i + 1].rank)
            {
                count++;
            }
        }
        if (count == 4)
        {
            Debug.Log("Straight!");
            SetBetValue(betValue + 5);

            return true;
        }
        else
        {
            return false;
        }
    }

    private bool IsPair(List<Card> hand)
    {
        Dictionary<Rank, int> repeats = new Dictionary<Rank, int>();

        for (int i = 0; i < hand.Count - 1; i++)
        {
            if (hand[i].rank == hand[i + 1].rank)
            {
                if (!repeats.ContainsKey(hand[i].rank))
                {
                    int count = hand.FindAll(x => x.rank == hand[i].rank).Count();
                    if (count > 1)
                    {
                        repeats.Add(hand[i].rank, count);
                    }
                }
            }
        }

        Debug.Log(repeats.Count);
        foreach (KeyValuePair<Rank, int> pair in repeats)
        {
            Debug.Log(pair.Key + " repeats " + pair.Value + " times");
        }

        if (repeats.ContainsValue(3))
        {
            Debug.Log("Three of a Kind!");
            SetBetValue(betValue + 3);

            return true;
        }

        if (repeats.Count >= 2)
        {
            if (repeats.ContainsValue(3) && repeats.ContainsValue(2))
            {
                Debug.Log("Full House!");
                SetBetValue(betValue + 10);

                return true;
            }
            else
            {
                Debug.Log("Two Pair!");
                SetBetValue(betValue + 2);

                return true;
            }
        }
        else
        {
            if (repeats.ContainsValue(4))
            {
                Debug.Log("Four of a Kind!");
                SetBetValue(betValue + 100);

                return true;
            }
            else
            {
                foreach (KeyValuePair<Rank, int> pair in repeats)
                {
                    if (pair.Key >= Rank.Jack)
                    {
                        Debug.Log("Is Jacks or Better!");
                        SetBetValue(betValue + 1);

                        return true;
                    }
                }
                return false;
            }
        }
    }

    /// <summary>
    /// Checks if given list of cards form a flush
    /// </summary>
    /// <param name="hand">card list</param>
    public bool IsFlush(List<Card> hand)
    {
        //creating a list of only ranks from the hand
        List<Rank> handRanks = new List<Rank>();
        foreach (Card card in hand)
        {
            handRanks.Add(card.rank);
        }
        handRanks.Reverse();

        //check for any flush
        if (hand.TrueForAll(x => x.suit == hand[0].suit))
        {
            //check if cards are in sequence
            int count = 0;
            for (int i = 0; i < handRanks.Count; i++)
            {
                if (handRanks[i] - 1 == handRanks[i + 1])
                {
                    count++;
                }
            }

            if (count == 4)
            {
                //check for royal flush
                List<Rank> royalFush = new List<Rank> { Rank.Ace, Rank.King, Rank.Queen, Rank.Jack, Rank.Ten };
                if (handRanks.SequenceEqual(royalFush))
                {
                    Debug.Log("Royal Flush!");
                    SetBetValue(betValue + 500);

                    return true;
                }
                else
                {
                    Debug.Log("Straight Flush!");
                    SetBetValue(betValue + 150);

                    return true;
                }
            }
            else
            {
                Debug.Log("Flush!");
                SetBetValue(betValue + 7);

                return true;
            }
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// Adds given card to heldCards list
    /// </summary>
    /// <param name="card">card to hold</param>
    public void HoldCard(Card card)
    {
        if (!heldCards.Contains(card))
        {
            heldCards.Add(card);
            card.gameObject.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f, 1f);
        }
    }

    /// <summary>
    /// Clears heldCards list and added back to deck
    /// </summary>
    public void Cancel()
    {
        if (dealCount < dealLimit && !isHand)
        {
            foreach (Card card in heldCards)
            {
                card.gameObject.GetComponent<Image>().color = Color.white;
                dealedCards.Add(card);
            }
            heldCards.Clear();
        }
    }

    public void Take()
    {
        if (isHand)
        {
            SetScore(betValue);
            StartCoroutine(APIHandler.TakeAmount(UserDetails.playerId, (response) =>
            {
                if(response.status == 200)
                {
                    Debug.Log(response.message);
                    ResetGame();
                }
            }));
        }
    }

    /// <summary>
    /// Loads double up panel, generates a random card and a choice
    /// </summary>
    public void Double_Up()
    {
        if (isHand)
        {
            //loading double up panel
            centerCards.gameObject.SetActive(false);
            doubleUpPanel.gameObject.SetActive(true);
        }
    }

    public void Big()
    {
        StartCoroutine(APIHandler.DoubleUp(UserDetails.playerId, "big", (response) =>
        {
            if(response.status == 200)
            {
                //receiving the double up card generated
                mysteryCard = deck.GetCard(response.data.double_up_card[0], response.data.double_up_card[1]);

                Instantiate(mysteryCard.gameObject, doubleUpPanel.transform);
                mysteryCard.transform.SetParent(doubleUpPanel.transform);

                //win amount (0 means guess was wrong)
                Debug.Log(response.data.win_amount);
                betValue = response.data.win_amount;
            }
        }));
    }

    public void Small()
    {
        StartCoroutine(APIHandler.DoubleUp(UserDetails.playerId, "small", (response) =>
        {
            if (response.status == 200)
            {
                //receiving the double up card generated
                mysteryCard = deck.GetCard(response.data.double_up_card[0], response.data.double_up_card[1]);

                Instantiate(mysteryCard.gameObject, doubleUpPanel.transform);
                mysteryCard.transform.SetParent(doubleUpPanel.transform);

                //win amount (0 means guess was wrong)
                Debug.Log(response.data.win_amount);
                betValue = response.data.win_amount;
            }
        }));
    }

    public void ResetGame()
    {
        SetBetValue(0);
        isHand = false;
        dealCount = 0;

        foreach (Card card in hand)
        {
            if (card != null)
                Destroy(card.gameObject);
        }
        heldCards.Clear();
    }

    public void CloseScene()
    {

    }
}
