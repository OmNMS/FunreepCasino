using System;
using System.Collections;
using System.Collections.Generic;

public static class UserDetails 
{
    public static string playerId;
}
